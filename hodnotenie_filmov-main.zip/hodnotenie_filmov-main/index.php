<!DOCTYPE html>
<html lang="en">

<?php
include_once './parts_of_website/header.php';
?>

<body>
  <?php

  include_once './parts_of_website/nav_bar.php';
  ?>
  <section>
    <h1>Vitajte na nasej stranke</h1>
  </section>
</body>

</html>